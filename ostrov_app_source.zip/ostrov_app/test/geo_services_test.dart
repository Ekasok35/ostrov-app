import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:ostrov/services/geo_services.dart';
import 'package:ostrov/models/place.dart';

void main() {
  group('Photon place parsing', () {
    test('builds a Russian address and coordinates', () {
      final place = Place.fromPhoton({
        'properties': {
          'name': 'Торговый центр',
          'street': 'улица Ленина',
          'housenumber': '123',
          'city': 'Южно-Сахалинск',
        },
        'geometry': {'coordinates': [142.738, 46.9591]},
      });
      expect(place.label, contains('Торговый центр'));
      expect(place.point.latitude, 46.9591);
      expect(place.point.longitude, 142.738);
    });

    test('rejects missing coordinates', () {
      expect(
        () => Place.fromPhoton({'properties': {}, 'geometry': {'coordinates': []}}),
        throwsFormatException,
      );
    });
  });

  group('service area', () {
    test('accepts a point inside the initial city bounds', () {
      expect(isInsideServiceArea(const LatLng(46.9591, 142.7380)), isTrue);
    });
    test('rejects a point outside the initial city bounds', () {
      expect(isInsideServiceArea(const LatLng(47.5, 142.7)), isFalse);
    });
  });
}
