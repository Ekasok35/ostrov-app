import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

import '../models/place.dart';

const cityCenter = LatLng(46.9591, 142.7380);
const cityBounds = '142.50,46.80,143.10,47.12';

class PhotonService {
  PhotonService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  Future<List<Place>> search(String query) async {
    final cleaned = query.trim();
    if (cleaned.length < 3) return const [];
    final uri = Uri.https('photon.komoot.io', '/api/', {
      'q': '$cleaned, Южно-Сахалинск',
      'lat': cityCenter.latitude.toString(),
      'lon': cityCenter.longitude.toString(),
      'limit': '8',
      'lang': 'ru',
      'bbox': cityBounds,
    });
    final response = await _client.get(uri, headers: const {
      'Accept': 'application/geo+json, application/json',
      'User-Agent': 'OSTROV-Passenger/0.1 (prototype; contact: configure-before-release)',
    }).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) {
      throw GeoServiceException('Поиск временно недоступен (${response.statusCode})');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Некорректный ответ геопоиска');
    }
    final features = decoded['features'];
    if (features is! List) return const [];
    final results = <Place>[];
    for (final feature in features) {
      if (feature is! Map<String, dynamic>) continue;
      try {
        final place = Place.fromPhoton(feature);
        if (isInsideServiceArea(place.point)) results.add(place);
      } on FormatException {
        // Skip malformed provider results instead of failing the whole search.
      }
    }
    return results;
  }

  Future<Place?> reverse(LatLng point) async {
    final uri = Uri.https('photon.komoot.io', '/reverse', {
      'lat': point.latitude.toString(),
      'lon': point.longitude.toString(),
      'lang': 'ru',
    });
    final response = await _client.get(uri, headers: const {
      'Accept': 'application/geo+json, application/json',
      'User-Agent': 'OSTROV-Passenger/0.1 (prototype; contact: configure-before-release)',
    }).timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) {
      throw GeoServiceException('Не удалось определить адрес точки');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic>) return null;
    final features = decoded['features'];
    if (features is! List || features.isEmpty || features.first is! Map<String, dynamic>) {
      return null;
    }
    final place = Place.fromPhoton(features.first as Map<String, dynamic>);
    return isInsideServiceArea(place.point) ? place : null;
  }

  void close() => _client.close();
}

class OsrmService {
  OsrmService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  Future<RouteInfo> route(LatLng from, LatLng to) async {
    final path = '/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}';
    final uri = Uri.https('router.project-osrm.org', path, {
      'overview': 'full',
      'geometries': 'geojson',
      'steps': 'false',
    });
    final response = await _client.get(uri, headers: const {
      'Accept': 'application/json',
      'User-Agent': 'OSTROV-Passenger/0.1 (prototype; contact: configure-before-release)',
    }).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw GeoServiceException('Маршрутный сервис временно недоступен');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! Map<String, dynamic> || decoded['code'] != 'Ok') {
      throw GeoServiceException('Не удалось построить маршрут между адресами');
    }
    final routes = decoded['routes'];
    if (routes is! List || routes.isEmpty || routes.first is! Map<String, dynamic>) {
      throw const FormatException('Маршрут не найден');
    }
    final route = routes.first as Map<String, dynamic>;
    final distance = route['distance'];
    final duration = route['duration'];
    final geometry = route['geometry'];
    if (distance is! num || duration is! num || geometry is! Map<String, dynamic>) {
      throw const FormatException('Маршрутный сервис вернул неполные данные');
    }
    final coordinates = geometry['coordinates'];
    if (coordinates is! List || coordinates.length < 2) {
      throw const FormatException('Геометрия маршрута отсутствует');
    }
    final points = <LatLng>[];
    for (final coordinate in coordinates) {
      if (coordinate is List && coordinate.length >= 2 &&
          coordinate[0] is num && coordinate[1] is num) {
        points.add(LatLng(
          (coordinate[1] as num).toDouble(),
          (coordinate[0] as num).toDouble(),
        ));
      }
    }
    if (points.length < 2) throw const FormatException('Маршрут пуст');
    return RouteInfo(
      points: points,
      distanceMeters: distance.toDouble(),
      durationSeconds: duration.toDouble(),
    );
  }

  void close() => _client.close();
}

bool isInsideServiceArea(LatLng point) {
  // First-version approximate operating boundary; refine with an official polygon.
  return point.latitude >= 46.80 && point.latitude <= 47.12 &&
      point.longitude >= 142.50 && point.longitude <= 143.10;
}

class GeoServiceException implements Exception {
  const GeoServiceException(this.message);
  final String message;
  @override
  String toString() => message;
}
