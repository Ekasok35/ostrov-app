import 'package:latlong2/latlong.dart';

class Place {
  const Place({required this.label, required this.point});

  final String label;
  final LatLng point;

  factory Place.fromPhoton(Map<String, dynamic> feature) {
    final properties = feature['properties'];
    final geometry = feature['geometry'];
    if (properties is! Map<String, dynamic> ||
        geometry is! Map<String, dynamic>) {
      throw const FormatException('Некорректный результат геопоиска');
    }
    final coordinates = geometry['coordinates'];
    if (coordinates is! List || coordinates.length < 2 ||
        coordinates[0] is! num || coordinates[1] is! num) {
      throw const FormatException('В результате отсутствуют координаты');
    }

    String value(String key) => (properties[key] is String)
        ? (properties[key] as String).trim()
        : '';
    final name = value('name');
    final street = value('street');
    final house = value('housenumber');
    final district = value('district');
    final city = value('city');
    final parts = <String>[
      if (name.isNotEmpty) name,
      if (street.isNotEmpty) street,
      if (house.isNotEmpty) house,
      if (district.isNotEmpty) district,
      if (city.isNotEmpty && city != 'Южно-Сахалинск') city,
    ];
    final unique = <String>[];
    for (final part in parts) {
      if (!unique.any((item) => item.toLowerCase() == part.toLowerCase())) {
        unique.add(part);
      }
    }
    final label = unique.isEmpty ? 'Выбранная точка' : unique.join(', ');
    return Place(
      label: label,
      point: LatLng(
        (coordinates[1] as num).toDouble(),
        (coordinates[0] as num).toDouble(),
      ),
    );
  }
}

class RouteInfo {
  const RouteInfo({
    required this.points,
    required this.distanceMeters,
    required this.durationSeconds,
  });

  final List<LatLng> points;
  final double distanceMeters;
  final double durationSeconds;

  String get distanceLabel {
    final km = distanceMeters / 1000;
    return km < 10 ? '${km.toStringAsFixed(1)} км' : '${km.toStringAsFixed(0)} км';
  }

  String get durationLabel {
    final minutes = (durationSeconds / 60).round();
    if (minutes < 60) return '$minutes мин';
    final hours = minutes ~/ 60;
    final rest = minutes % 60;
    return rest == 0 ? '$hours ч' : '$hours ч $rest мин';
  }
}
