import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../theme.dart';
import '../models/place.dart';
import '../services/geo_services.dart';
import '../services/location_service.dart';

class BookingPage extends StatefulWidget {
  const BookingPage({super.key});
  @override
  State<BookingPage> createState() => _BookingPageState();
}

enum _AddressField { pickup, destination }
enum _RideClass { economy, comfort }
enum _PaymentMethod { cash, card }

class _BookingPageState extends State<BookingPage> {
  final _pickupController = TextEditingController();
  final _destinationController = TextEditingController();
  final _mapController = MapController();
  final _photon = PhotonService();
  final _osrm = OsrmService();
  final _location = LocationService();

  _AddressField _activeField = _AddressField.destination;
  _RideClass _rideClass = _RideClass.economy;
  _PaymentMethod _payment = _PaymentMethod.cash;
  Place? _pickup;
  Place? _destination;
  RouteInfo? _route;
  Timer? _debounce;
  List<Place> _suggestions = [];
  bool _searching = false;
  bool _locating = false;
  bool _routing = false;
  String? _searchError;
  int _searchToken = 0;
  int _routeToken = 0;

  @override
  void dispose() {
    _debounce?.cancel();
    _pickupController.dispose();
    _destinationController.dispose();
    _mapController.dispose();
    _photon.close();
    _osrm.close();
    super.dispose();
  }

  void _notify(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _onQueryChanged(_AddressField field, String value) {
    _activeField = field;
    _debounce?.cancel();
    final token = ++_searchToken;
    _routeToken++;
    if (field == _AddressField.pickup && _pickup != null && _pickup!.label != value) {
      _pickup = null;
    }
    if (field == _AddressField.destination && _destination != null && _destination!.label != value) {
      _destination = null;
    }
    _route = null;
    if (value.trim().length < 3) {
      setState(() { _suggestions = []; _searching = false; _searchError = null; });
      return;
    }
    setState(() { _searching = true; _searchError = null; _suggestions = []; });
    _debounce = Timer(const Duration(milliseconds: 650), () async {
      try {
        final results = await _photon.search(value);
        if (!mounted || token != _searchToken) return;
        setState(() { _suggestions = results; _searching = false; });
        if (results.isEmpty) setState(() => _searchError = 'В Южно-Сахалинске ничего не найдено. Попробуйте уточнить адрес.');
      } catch (error) {
        if (!mounted || token != _searchToken) return;
        setState(() { _searching = false; _searchError = error.toString(); });
      }
    });
  }

  void _selectPlace(Place place) {
    _debounce?.cancel();
    _searchToken++;
    _routeToken++;
    setState(() {
      if (_activeField == _AddressField.pickup) {
        _pickup = place;
        _pickupController.text = place.label;
      } else {
        _destination = place;
        _destinationController.text = place.label;
      }
      _suggestions = [];
      _searchError = null;
      _route = null;
    });
    _mapController.move(place.point, 16);
    _maybeBuildRoute();
  }

  Future<void> _selectMapPoint(LatLng point) async {
    _debounce?.cancel();
    _searchToken++;
    _routeToken++;
    if (!isInsideServiceArea(point)) {
      _notify('Пока OSTROV работает только в Южно-Сахалинске.');
      return;
    }
    setState(() { _searching = true; _searchError = null; _suggestions = []; });
    try {
      final place = await _photon.reverse(point) ?? Place(
        label: 'Точка на карте (${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)})',
        point: point,
      );
      if (!mounted) return;
      _selectPlace(place);
    } catch (_) {
      if (!mounted) return;
      _selectPlace(Place(
        label: 'Точка на карте (${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)})',
        point: point,
      ));
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _useCurrentLocation() async {
    setState(() => _locating = true);
    try {
      final point = await _location.currentPosition();
      if (!isInsideServiceArea(point)) {
        throw const LocationException('Вы находитесь за пределами зоны работы OSTROV.');
      }
      final place = await _photon.reverse(point) ?? Place(
        label: 'Моё местоположение', point: point,
      );
      if (!mounted) return;
      setState(() {
        _pickup = place;
        _pickupController.text = place.label;
        _activeField = _AddressField.destination;
      });
      _mapController.move(point, 16);
      await _maybeBuildRoute();
    } catch (error) {
      _notify(error.toString());
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _maybeBuildRoute() async {
    final pickup = _pickup;
    final destination = _destination;
    if (pickup == null || destination == null) return;
    final token = ++_routeToken;
    setState(() { _routing = true; _route = null; });
    try {
      final route = await _osrm.route(pickup.point, destination.point);
      if (!mounted || token != _routeToken) return;
      setState(() => _route = route);
      final bounds = LatLngBounds.fromPoints(route.points);
      _mapController.fitCamera(CameraFit.bounds(
        bounds: bounds,
        padding: const EdgeInsets.fromLTRB(40, 40, 40, 40),
        maxZoom: 16,
      ));
    } catch (error) {
      if (mounted && token == _routeToken) _notify(error.toString());
    } finally {
      if (mounted && token == _routeToken) setState(() => _routing = false);
    }
  }

  Future<void> _requestRide() async {
    if (_pickup == null || _destination == null) {
      _notify('Выберите адрес отправления и назначения из подсказок или на карте.');
      return;
    }
    if (_route == null) {
      await _maybeBuildRoute();
      if (!mounted || _route == null) return;
    }
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Проверка заказа', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Text('Откуда: ${_pickup!.label}'),
              const SizedBox(height: 6),
              Text('Куда: ${_destination!.label}'),
              const SizedBox(height: 12),
              Text('Маршрут: ${_route!.distanceLabel} · ${_route!.durationLabel}'),
              const SizedBox(height: 8),
              Text('Тариф: ${_rideClass == _RideClass.economy ? "Эконом" : "Комфорт"}'),
              Text('Оплата: ${_payment == _PaymentMethod.cash ? "Наличные" : "Карта"}'),
              const SizedBox(height: 12),
              const Text('Стоимость и отправка заказа появятся после подключения серверных тарифов и диспетчерской OSTROV.', style: TextStyle(color: Colors.blueGrey)),
              const SizedBox(height: 18),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: () => Navigator.pop(sheetContext),
                child: const Text('Понятно'),
              )),
            ],
          ),
        ),
      ),
    );
  }

  List<Marker> get _markers => [
    if (_pickup != null) Marker(
      point: _pickup!.point, width: 42, height: 48,
      child: const Icon(Icons.location_on, color: ostrovBlue, size: 42),
    ),
    if (_destination != null) Marker(
      point: _destination!.point, width: 42, height: 48,
      child: const Icon(Icons.location_on, color: Color(0xFFE07878), size: 42),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.navigation_rounded, color: ostrovBlue, size: 28),
          SizedBox(width: 8),
          Text('OSTROV', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ]),
        actions: [IconButton(
          tooltip: 'Моё местоположение',
          onPressed: _locating ? null : _useCurrentLocation,
          icon: _locating
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.my_location),
        )],
      ),
      body: SafeArea(child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Куда отправимся сегодня?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Такси по Южно-Сахалинску', style: TextStyle(color: Colors.blueGrey)),
          const SizedBox(height: 14),
          SizedBox(height: 270, child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: cityCenter, initialZoom: 13,
                minZoom: 10, maxZoom: 19,
                onTap: (_, point) => _selectMapPoint(point),
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'ru.ostrov.taxi',
                  maxNativeZoom: 19,
                ),
                if (_route != null) PolylineLayer(polylines: [
                  Polyline(points: _route!.points, strokeWidth: 5, color: ostrovBlue),
                ]),
                MarkerLayer(markers: _markers),
                RichAttributionWidget(
                  alignment: AttributionAlignment.bottomRight,
                  attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
                ),
              ],
            ),
          )),
          const SizedBox(height: 7),
          const Text('Нажмите на карту, чтобы выбрать точку. Для адреса используйте поиск.', style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
          const SizedBox(height: 14),
          Card(color: Colors.white, elevation: 0, child: Padding(
            padding: const EdgeInsets.all(13),
            child: Column(children: [
              _addressInput(_AddressField.pickup, _pickupController, 'Откуда', Icons.my_location),
              const Divider(height: 14),
              _addressInput(_AddressField.destination, _destinationController, 'Куда', Icons.location_on_outlined),
              if (_searching) const Padding(
                padding: EdgeInsets.all(10),
                child: Row(children: [SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 10), Text('Ищем адрес…')]),
              ),
              if (_searchError != null) Padding(
                padding: const EdgeInsets.all(8),
                child: Text(_searchError!, style: const TextStyle(color: Colors.red, fontSize: 12)),
              ),
              if (_suggestions.isNotEmpty) Container(
                constraints: const BoxConstraints(maxHeight: 220),
                margin: const EdgeInsets.only(top: 8),
                decoration: BoxDecoration(color: ostrovIce, borderRadius: BorderRadius.circular(12)),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: _suggestions.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final place = _suggestions[index];
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.place_outlined, color: ostrovBlue),
                      title: Text(place.label, style: const TextStyle(fontSize: 13)),
                      onTap: () => _selectPlace(place),
                    );
                  },
                ),
              ),
            ]),
          )),
          const SizedBox(height: 18),
          const Text('Выберите тариф', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 9),
          Row(children: [
            Expanded(child: _TariffCard(
              title: 'Эконом', subtitle: 'На каждый день', icon: Icons.directions_car,
              selected: _rideClass == _RideClass.economy,
              onTap: () => setState(() => _rideClass = _RideClass.economy),
            )),
            const SizedBox(width: 10),
            Expanded(child: _TariffCard(
              title: 'Комфорт', subtitle: 'Больше удобства', icon: Icons.airline_seat_recline_extra,
              selected: _rideClass == _RideClass.comfort,
              onTap: () => setState(() => _rideClass = _RideClass.comfort),
            )),
          ]),
          const SizedBox(height: 17),
          const Text('Способ оплаты', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          SegmentedButton<_PaymentMethod>(
            segments: const [
              ButtonSegment(value: _PaymentMethod.cash, label: Text('Наличные'), icon: Icon(Icons.payments_outlined)),
              ButtonSegment(value: _PaymentMethod.card, label: Text('Карта'), icon: Icon(Icons.credit_card)),
            ],
            selected: {_payment},
            onSelectionChanged: (value) => setState(() => _payment = value.first),
          ),
          if (_route != null) Card(
            color: Colors.white, elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Маршрут', style: TextStyle(fontWeight: FontWeight.w700)),
                Text('${_route!.distanceLabel} · ${_route!.durationLabel}', style: const TextStyle(color: ostrovBlue, fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
          if (_routing) const LinearProgressIndicator(),
          const SizedBox(height: 14),
          SizedBox(height: 54, child: FilledButton(
            onPressed: _routing ? null : _requestRide,
            child: const Text('Продолжить', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          )),
          const SizedBox(height: 12),
          const Text('Приём заказов — круглосуточно · Поддержка — 08:00–23:00', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
          const SizedBox(height: 5),
          const Text('Карта и поиск используют демонстрационные публичные сервисы. Перед коммерческим запуском подключается производственная инфраструктура.', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Colors.blueGrey)),
        ],
      )),
    );
  }

  Widget _addressInput(_AddressField field, TextEditingController controller, String label, IconData icon) {
    return TextField(
      controller: controller,
      onTap: () {
        _debounce?.cancel();
        _searchToken++;
        setState(() { _activeField = field; _suggestions = []; _searching = false; _searchError = null; });
      },
      onChanged: (value) => _onQueryChanged(field, value),
      decoration: InputDecoration(
        labelText: label,
        hintText: field == _AddressField.pickup ? 'Адрес подачи' : 'Улица, дом или организация',
        prefixIcon: Icon(icon, color: ostrovBlue),
        suffixIcon: controller.text.isEmpty ? null : IconButton(
          tooltip: 'Очистить адрес',
          onPressed: () {
            controller.clear();
            setState(() {
              _routeToken++;
              if (field == _AddressField.pickup) _pickup = null; else _destination = null;
              _route = null; _suggestions = []; _searchError = null;
            });
          },
          icon: const Icon(Icons.close),
        ),
      ),
    );
  }
}

class _TariffCard extends StatelessWidget {
  const _TariffCard({required this.title, required this.subtitle, required this.icon, required this.selected, required this.onTap});
  final String title;
  final String subtitle;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFFD9F1FC) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: selected ? ostrovBlue : const Color(0xFFDDEAF1), width: selected ? 2 : 1),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: ostrovBlue, size: 29),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
      ]),
    ),
  );
}
